package com.neontoolkit.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQUEST_EXPORT = 1001;
    private static final int REQUEST_IMPORT = 1002;
    private WebView webView;
    private String pendingExportJson = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(15, 13, 22));
        getWindow().setNavigationBarColor(Color.rgb(15, 13, 22));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(15, 13, 22));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new NativeBridge(), "NeonNative");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private class NativeBridge {
        @JavascriptInterface
        public void exportJson(String json) {
            runOnUiThread(() -> {
                pendingExportJson = json == null ? "{}" : json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "neon-toolkit-backup.json");
                startActivityForResult(intent, REQUEST_EXPORT);
            });
        }

        @JavascriptInterface
        public void importJson() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                startActivityForResult(intent, REQUEST_IMPORT);
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent resultData) {
        super.onActivityResult(requestCode, resultCode, resultData);
        if (resultCode != RESULT_OK || resultData == null || resultData.getData() == null) {
            if (webView != null) webView.evaluateJavascript("window.onNativeFileCancelled && window.onNativeFileCancelled()", null);
            return;
        }
        Uri uri = resultData.getData();
        try {
            if (requestCode == REQUEST_EXPORT) {
                try (OutputStream output = getContentResolver().openOutputStream(uri)) {
                    if (output == null) throw new Exception("Could not open output");
                    output.write(pendingExportJson.getBytes(StandardCharsets.UTF_8));
                    output.flush();
                }
                if (webView != null) webView.evaluateJavascript("window.onNativeExportDone && window.onNativeExportDone(true)", null);
            } else if (requestCode == REQUEST_IMPORT) {
                StringBuilder content = new StringBuilder();
                try (InputStream input = getContentResolver().openInputStream(uri)) {
                    if (input == null) throw new Exception("Could not open input");
                    byte[] buffer = new byte[4096];
                    int count;
                    while ((count = input.read(buffer)) != -1) content.append(new String(buffer, 0, count, StandardCharsets.UTF_8));
                }
                String encoded = org.json.JSONObject.quote(content.toString());
                if (webView != null) webView.evaluateJavascript("window.onNativeImport && window.onNativeImport(" + encoded + ")", null);
            }
        } catch (Exception error) {
            if (webView != null) webView.evaluateJavascript("window.onNativeFileError && window.onNativeFileError()", null);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript(
                "if(window.handleAndroidBack){window.handleAndroidBack()}",
                null
            );
        } else {
            super.onBackPressed();
        }
    }
}
