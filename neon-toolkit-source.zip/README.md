# NEON TOOLKIT

A minimal Android companion app prototype for Android 9 (API 28) and newer.

## Included in v1.0 prototype
- Four tabs: Dashboard, Crosshair Studio, Display Lab, Settings.
- Crosshair editor with live preview and local saved presets.
- Display aspect-ratio/scale preview with saved presets.
- Russian and English interface.
- Local JSON backup export and import through Android's file picker.
- Setup welcome dialog.
- GitHub Actions workflow for building a debug APK.

## Important limitations
- Display Lab changes only its own demonstration preview. It does not stretch Standoff 2 or change system resolution.
- A floating overlay crosshair is not included in this first build.
- This is a debug APK for testing, not a production-signed release.

## Build
GitHub Actions runs on pushes to `main`/`master` and can also be started manually from Actions → Build NEON TOOLKIT APK → Run workflow.
Download `neon-toolkit-debug-apk` from the completed workflow run's Artifacts section.
